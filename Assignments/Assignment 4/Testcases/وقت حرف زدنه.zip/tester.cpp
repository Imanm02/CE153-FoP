/*
 * tester.cpp
 */

#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main(int argc, char const *argv[])
{

    ifstream test_in(argv[1]);    /* This stream reads from test's input file   */
    ifstream test_out(argv[2]);   /* This stream reads from test's output file  */
    ifstream user_out(argv[3]);   /* This stream reads from user's output file  */
    ifstream text("code.c");

    string user_output, answer;

    /* Your code here */
    /* If user's output is correct, return 0, otherwise return 1       */

    char aWord[100];
    int count = 0;
    while (text.good()) {
        text>>aWord;
        if (text.good() && strcmp(aWord, "char") == 0) {
            count++;
        }
        if (text.good() && (aWord.find("while") == 0 || aWord.find("for") == 0)) {
            return 0;
        }
        if (text.good() && strcmp(aWord, "int") == 0) {
            text>>aWord;
            if (!(text.good() && strcmp(aWord, "main()") == 0)) {
                return 1;
            }
        }
    }
    if (count > 2)
        return 1;

    user_out >> user_output;


    if ( test_out.good() ) // if test's output file exists
	{
		test_out >> answer;
	}

    if (strcmp(user_output,answer))
        return 0;
    else
        return 1;
    
}