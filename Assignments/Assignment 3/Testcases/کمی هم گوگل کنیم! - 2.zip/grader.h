#define s 1
int main();
#if s == 0
long long findDivisorSum(char c, int num1, int num2, int num3);
#else
long long findDivisorSum(int n, ...);
long long run(char type, int num1, int num2, int num3, int num4);
#endif
