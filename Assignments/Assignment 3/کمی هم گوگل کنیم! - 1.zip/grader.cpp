#include <iostream>
#include "grader.h"
using namespace std;

#if s == 0
int main() {
    int num1, num2, num3, num4;
    cin >> num1 >> num2 >> num3 >> num4;
    cout << run('m', num1, num2, num3, num4) << endl;
    cout << run('M', num1, num2, num3, num4) << endl;
    return 0;
}
#else
int main() {
    int n;
    cin >> n;
    int a[n];
    for(int i = 0; i < n; i++) {
        cin >> a[i];
    }
    cout << findDivisorSum(n, a);
}
#endif